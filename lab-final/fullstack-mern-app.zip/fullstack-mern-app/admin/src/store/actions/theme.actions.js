export const changeMenuBackgroundColor = (color) => {
  return {
    type: "change_menu_background_color",
    data: color,
  };
};
