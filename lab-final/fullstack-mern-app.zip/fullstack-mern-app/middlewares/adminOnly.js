module.exports = function adminOnly(req, res, next) {
  const usr = req.session.user;
    if (usr && usr.roles && usr.roles.includes("admin")) {
        return next();
    } else {
        req.flash("error", "Access denied. Admins only.");
        return res.redirect("/login");
    }

    next();
};