/**
 * Middleware to check if cart is not empty
 * Prevents checkout when cart is empty
 */
const checkCartNotEmpty = (req, res, next) => {
  const cart = req.session.cart || [];

  if (!cart || cart.length === 0) {
    req.flash('error', 'Your cart is empty. Please add some products before checkout.');
    return res.redirect('/cart');
  }

  next();
};

module.exports = checkCartNotEmpty;