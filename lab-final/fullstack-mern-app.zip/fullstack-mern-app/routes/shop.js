var express = require("express");
var router = express.Router();
var Product = require("../models/Product");
const Category = require("../models/Category");
const Order = require("../models/Order");
const checkCartNotEmpty = require("../middlewares/checkCartNotEmpty");

// View Cart
router.get("/cart", async function (req, res) {
  let cart = req.session.cart || [];
  let products = await Product.find({ _id: { $in: cart } });

  let total = products.reduce((sum, product) => {
    let cleanPrice = product.price.toString().replace(/,/g, "");
    return sum + Number(cleanPrice);
  }, 0);

  res.render("site/cart", { 
    layout: false, 
    products, 
    total, 
    activePage: 'cart', 
    pagetitle: 'Shopping Cart' 
  });
});

// Add to Cart
router.get("/add-cart/:id", function (req, res) {
  let cart = req.session.cart || [];
  cart.push(req.params.id);
  req.session.cart = cart;
  req.flash("success", "Product Added To Cart");
  res.redirect("/shop");
});

// Remove from Cart
router.get("/remove-cart/:id", function (req, res) {
  let cart = req.session.cart || [];
  cart = cart.filter(item => item !== req.params.id);
  req.session.cart = cart;
  req.flash("success", "Product Removed From Cart");
  res.redirect("/cart");
});

// Checkout Page
router.get("/checkout", checkCartNotEmpty, async function (req, res) {
  let cart = req.session.cart || [];
  let products = await Product.find({ _id: { $in: cart } });

  let total = products.reduce((sum, product) => {
    let cleanPrice = product.price.toString().replace(/,/g, "");
    return sum + Number(cleanPrice);
  }, 0);

  res.render("site/checkout", { 
    layout: false, 
    products, 
    total, 
    activePage: 'checkout', 
    pagetitle: 'Checkout' 
  });
});

// Place Order
router.post("/place-order", checkCartNotEmpty, async function (req, res) {
  try {
    let cart = req.session.cart || [];
    if (!cart.length) {
      req.flash("error", "Your cart is empty!");
      return res.redirect("/shop");
    }

    let products = await Product.find({ _id: { $in: cart } });

    let cartItems = products.map(p => ({
      product: p._id,
      quantity: 1, // extend if quantity is stored
      price: Number(p.price.toString().replace(/,/g, ''))
    }));

    let totalAmount = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

    const { customerName, email } = req.body;

    const order = new Order({
      customerName,
      email,
      cartItems,
      totalAmount
    });

    await order.save();

    req.session.cart = []; // Clear cart
    req.flash("success", "Order placed successfully!");
    res.redirect(`/super-admin/order-confirmation/${order._id}`);
  } catch (err) {
    console.error(err);
    req.flash("error", "Something went wrong!");
    res.redirect("/shop");
  }
});

// Category Products
router.get("/category/:name", async function (req, res) {
  let categoryName = req.params.name;

  let categories = await Category.find();
  let products = await Product.find({ category: categoryName });

  res.render("site/collections/Catetorys", {
    Category_title: categoryName,
    categories,
    products,
  });
});

// Shop Listing with Filters and Pagination
router.get("/shop/:page?", async function (req, res) {
  let page = Number(req.params.page) || 1;
  let pageSize = 10;

  let { category, minPrice, maxPrice } = req.query;

  let allProducts = await Product.find({});

  // Category filter
  if (category && category !== '') {
    allProducts = allProducts.filter(product => 
      product.department && product.department.toLowerCase() === category.toLowerCase()
    );
  }

  // Price filter
  if ((minPrice && !isNaN(minPrice)) || (maxPrice && !isNaN(maxPrice))) {
    allProducts = allProducts.filter(product => {
      let productPrice = Number(product.price.toString().replace(/,/g, ''));
      let minCheck = minPrice ? productPrice >= Number(minPrice) : true;
      let maxCheck = maxPrice ? productPrice <= Number(maxPrice) : true;
      return minCheck && maxCheck;
    });
  }

  let totalProducts = allProducts.length;
  let totalPages = Math.ceil(totalProducts / pageSize);
  let startIndex = (page - 1) * pageSize;
  let endIndex = startIndex + pageSize;
  let products = allProducts.slice(startIndex, endIndex);

  res.render("site/homepage", {
    layout: false,
    activePage: 'products',
    pagetitle: "Awesome Products",
    products,
    page,
    pageSize,
    totalPages,
    currentFilters: {
      category: category || '',
      minPrice: minPrice || '',
      maxPrice: maxPrice || ''
    }
  });
});

module.exports = router;
