const express = require("express");
let router = express.Router();
const Order = require("../../models/Order"); // adjust path to your lab-final folder
const adminOnly = require("../../middlewares/adminOnly"); // admin access middleware

// Super Admin Dashboard
router.get("/", async (req, res) => {
  return res.render("super-admin/dashboard", { 
    layout: false, 
    activePage: 'super-admin', 
    pagetitle: "Super Admin Dashboard" 
  });
});

// Admin Orders Page
router.get("/order", adminOnly, async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 }).populate('cartItems.product');
    res.render("lab-final/admin-orders", { orders });
  } catch (err) {
    console.error(err);
    req.flash("error", "Could not load orders");
    res.redirect("/super-admin");
  }
});

// Update Order Status (Confirm / Cancel)
router.post("/order/:id/status", adminOnly, async (req, res) => {
  try {
    const { status } = req.body; // "Confirmed" or "Cancelled"
    await Order.findByIdAndUpdate(req.params.id, { status });
    req.flash("success", "Order status updated");
    res.redirect("/super-admin/order");
  } catch (err) {
    console.error(err);
    req.flash("error", "Could not update order status");
    res.redirect("/super-admin/order");
  }
});

module.exports = router;
